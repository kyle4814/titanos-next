AI for Tradies, Start to Finish (TITANOS, version 1, 29 November 2026)

Start with course-ai-for-tradies.pdf (the full workbook, all twelve lessons and appendices).
lesson-notes/      the twelve lessons as separate PDFs
templates/         quote follow-up and invoice reminder message packs (plain text, copy and paste)
sheets/            time log, quote tracker, money owed, results (open in any spreadsheet program)
privacy-and-safety-one-pager.pdf   print and pin up
course-completion-checklist.pdf    tick off as you go

General information only, not legal, tax or financial advice. Video is not part of version one.
